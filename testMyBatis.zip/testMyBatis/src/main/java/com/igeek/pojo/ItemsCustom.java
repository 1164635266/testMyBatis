package com.igeek.pojo;

//ItemsCustom 是Items的拓展类
public class ItemsCustom extends Items {
}
